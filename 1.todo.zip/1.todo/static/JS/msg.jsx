// Message.jsx
import React from 'react';

const Message = () => {
  return (
    <div>
      <h2>Important Message</h2>
      <p>This is the message you wanted to display.</p>
    </div>
  );
};

export default Message;


