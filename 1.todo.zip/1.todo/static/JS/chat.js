document.getElementById('openChatButton').addEventListener('click', function() {
    document.getElementById('aiMessengerPopup').classList.remove('hidden');
});

document.getElementById('sendQueryButton').addEventListener('click', function() {
    // Implement send message functionality here
});
