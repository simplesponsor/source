from django.shortcuts import render, get_object_or_404, redirect # type: ignore
from .models import Course, ReviewRating, CourseGallery
from category.models import Category
from carts.models import CartItem
from django.db.models import Q # type: ignore

from carts.views import _cart_id
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator # type: ignore
from django.http import HttpResponse # type: ignore
from .forms import ReviewForm
from django.contrib import messages # type: ignore
from enrolls.models import EnrollCourse


def store(request, category_slug=None):
    categories = None
    courses = None

    if category_slug != None:
        categories = get_object_or_404(Category, slug=category_slug)
        courses = Course.objects.filter(category=categories, is_available=True)
        paginator = Paginator(courses, 1)
        page = request.GET.get('page')
        paged_courses = paginator.get_page(page)
        course_count = courses.count()
    else:
        courses = Course.objects.all().filter(is_available=True).enroll_by('id')
        paginator = Paginator(courses, 3)
        page = request.GET.get('page')
        paged_courses = paginator.get_page(page)
        course_count = courses.count()

    context = {
        'courses': paged_courses,
        'course_count': course_count,
    }
    return render(request, 'store/store.html', context)


def course_detail(request, category_slug, course_slug):
    try:
        single_course = Course.objects.get(category__slug=category_slug, slug=course_slug)
        in_cart = CartItem.objects.filter(cart__cart_id=_cart_id(request), course=single_course).exists()
    except Exception as e:
        raise e

    if request.user.is_authenticated:
        try:
            enrollcourse = EnrollCourse.objects.filter(user=request.user, course_id=single_course.id).exists()
        except EnrollCourse.DoesNotExist:
            enrollcourse = None
    else:
        enrollcourse = None

    # Get the reviews
    reviews = ReviewRating.objects.filter(course_id=single_course.id, status=True)

    # Get the course gallery
    course_gallery = CourseGallery.objects.filter(course_id=single_course.id)

    context = {
        'single_course': single_course,
        'in_cart'       : in_cart,
        'enrollcourse': enrollcourse,
        'reviews': reviews,
        'course_gallery': course_gallery,
    }
    return render(request, 'store/course_detail.html', context)


def search(request):
    if 'keyword' in request.GET:
        keyword = request.GET['keyword']
        if keyword:
            courses = Course.objects.enroll_by('-created_date').filter(Q(description__icontains=keyword) | Q(course_name__icontains=keyword))
            course_count = courses.count()
    context = {
        'courses': courses,
        'course_count': course_count,
    }
    return render(request, 'store/store.html', context)


def submit_review(request, course_id):
    url = request.META.get('HTTP_REFERER')
    if request.method == 'POST':
        try:
            reviews = ReviewRating.objects.get(user__id=request.user.id, course__id=course_id)
            form = ReviewForm(request.POST, instance=reviews)
            form.save()
            messages.success(request, 'Thank you! Your review has been updated.')
            return redirect(url)
        except ReviewRating.DoesNotExist:
            form = ReviewForm(request.POST)
            if form.is_valid():
                data = ReviewRating()
                data.subject = form.cleaned_data['subject']
                data.rating = form.cleaned_data['rating']
                data.review = form.cleaned_data['review']
                data.ip = request.META.get('REMOTE_ADDR')
                data.course_id = course_id
                data.user_id = request.user.id
                data.save()
                messages.success(request, 'Thank you! Your review has been submitted.')
                return redirect(url)
