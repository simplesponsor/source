from django.contrib import admin
from .models import Course, Variation, ReviewRating, CourseGallery
import admin_thumbnails

@admin_thumbnails.thumbnail('image')
class CourseGalleryInline(admin.TabularInline):
    model = CourseGallery
    extra = 1

class CourseAdmin(admin.ModelAdmin):
    list_display = ('course_name', 'price', 'stock', 'category', 'modified_date', 'is_available')
    prepopulated_fields = {'slug': ('course_name',)}
    inlines = [CourseGalleryInline]

class VariationAdmin(admin.ModelAdmin):
    list_display = ('course', 'variation_category', 'variation_value', 'is_active')
    list_editable = ('is_active',)
    list_filter = ('course', 'variation_category', 'variation_value')

admin.site.register(Course, CourseAdmin)
admin.site.register(Variation, VariationAdmin)
admin.site.register(ReviewRating)
admin.site.register(CourseGallery)
