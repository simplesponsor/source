from django.contrib import admin
from .models import Payment, Order, OrderCourse
# Register your models here.


class EnrollCourseInline(admin.TabularInline):
    model = EnrollCourse
    readonly_fields = ('payment', 'user', 'course', 'quantity', 'course_price', 'Enrolled')
    extra = 0

class EnrollAdmin(admin.ModelAdmin):
    list_display = ['enroll_number', 'full_name', 'phone', 'email', 'city', 'enroll_total', 'tax', 'status', 'is_enrolled', 'created_at']
    list_filter = ['status', 'is_enrolled']
    search_fields = ['enroll_number', 'first_name', 'last_name', 'phone', 'email']
    list_per_page = 20
    inlines = [EnrollCourseInline]

admin.site.register(Payment)
admin.site.register(Enroll, EnrollAdmin)
admin.site.register(EnrollCourse)
