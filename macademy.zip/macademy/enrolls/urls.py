from django.urls import path
from . import views

urlpatterns = [
    path('place_enroll/', views.place_enroll, name='place_enroll'),
    path('payments/', views.payments, name='payments'),
    path('enroll_complete/', views.enroll_complete, name='enroll_complete'),
]
