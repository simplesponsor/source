from django.shortcuts import render
from store.models import Course, ReviewRating

def home(request):
    courses = Course.objects.all().filter(is_available=True).order_by('created_date')

    # Get the reviews
    reviews = None
    for course in courses:
        reviews = ReviewRating.objects.filter(course_id=course.id, status=True)

    context = {
        'courses': courses,
        'reviews': reviews,
    }
    return render(request, 'home.html', context)
